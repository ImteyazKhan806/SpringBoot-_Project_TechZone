package com.ecomm.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecomm.model.Category;
import com.ecomm.model.Product;
import com.ecomm.model.UserDtls;
import com.ecomm.service.CartService;
import com.ecomm.service.CategoryService;
import com.ecomm.service.ProductService;
import com.ecomm.service.UserService;
import com.ecomm.util.CommonUtil;

import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


@Controller
public class HomeController {
    
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@ModelAttribute
	public void getUserDetails(Principal p, Model m) {
		
		if(p != null) {
			String email= p.getName();
			UserDtls userEmail = userService.getUserByEmail(email);
			m.addAttribute("user",userEmail);
			Integer countCart = cartService.getCountCart(userEmail.getId());
			m.addAttribute("countCart", countCart);
			
		}
		List<Category> category = categoryService.getAllActiveCategory();
		m.addAttribute("categorys",category);
	}
	
    @GetMapping("/")
	public String index(Model m) {
		List<Category> allActiveCategory= categoryService.getAllActiveCategory().stream()
				.sorted((c1, c2)->c1.getId().compareTo(c1.getId()))   
				.limit(6).toList();     //descending order by ID 
		
		List<Product> allActiveProduct = productService.getAllActiveProduct("").stream()
	           .sorted((p1, p2)->p2.getId().compareTo(p1.getId()))
				.limit(8).toList();      //descending order by ID
		
		m.addAttribute("category",allActiveCategory);
		m.addAttribute("products",allActiveProduct);
		return "index";
	}
    
    @GetMapping("/signin")
  	public String login() {
  		
  		return "login";
  	}
    
    @GetMapping("/signup")
  	public String signup() {
  		
  		return "signup";
  	}
    
    @GetMapping("/products")
  	public String products(Model m, @RequestParam(value = "category", defaultValue ="") String category, 
  			@RequestParam(name ="pageNo", defaultValue = "0") Integer pageNo,
  			@RequestParam(name ="pageSize", defaultValue = "9")Integer pageSize, @RequestParam(defaultValue ="") String ch) {
    	
  		List<Category> categories = categoryService.getAllActiveCategory();
  		m.addAttribute("categories", categories);
  		m.addAttribute("paramValue", category);
  	//	List<Product> products = productService.getAllActiveProduct(category);
  	//	m.addAttribute("products" ,products);
  		
  		Page<Product> page = null;
  		if(StringUtils.isEmpty(ch)) {
  			
  			page = productService.getAllActiveProductPagination(pageNo, pageSize, category);
  		}else {
  			
  			page = productService.searchActiveProductPagination(pageNo, pageSize, category, ch);
  		}
  		
  		List<Product> products = page.getContent();
  		products = productService.getAllActiveProduct(category);
  		m.addAttribute("productsSize", products.size());
  		m.addAttribute("products",products);
  		m.addAttribute("pageNo",page.getNumber());
  		m.addAttribute("pageSize",pageSize);
  		m.addAttribute("totalElements",page.getTotalElements());
  		m.addAttribute("totalPages",page.getTotalPages());
  		m.addAttribute("isFirst",page.isFirst());
  		m.addAttribute("isLast",page.isLast());
  		return "product";
  	}
    
    @GetMapping("/product/{id}")
  	public String product(@PathVariable int id, Model m) {
  		
    	Product productById = productService.getProductById(id);
    	m.addAttribute("product", productById);
  		return "view_product";
  	}
    
    @PostMapping("/saveUser")
   public String saveUser(@ModelAttribute UserDtls user, @RequestParam("image") MultipartFile file, HttpSession session)  {
	   
     try {
    	Boolean existsEmail = userService.existsEmail(user.getEmail());
    	
    	if(existsEmail) {
    		session.setAttribute("errorMsg", "Email already exists");
    	}else {
    		
    		 String imageName = file.isEmpty() ? "default.jpg" : file.getOriginalFilename();
             user.setProfileImage(imageName);
             
        	UserDtls saveUser = userService.saveUser(user);
        	
        	if(!ObjectUtils.isEmpty(saveUser)) {
        		
        		if(!file.isEmpty()) {
        			
    					
        				File savefile = new ClassPathResource("static/images").getFile();

        				Path path = Paths.get(savefile.getAbsolutePath() + File.separator + "profile_img" + File.separator
        						+ file.getOriginalFilename());
        				// System.out.println(path); // call the path of image

        				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
        				
        		}
        		session.setAttribute("successMsg", " Signup Saved successfully");
        	}else {
        		session.setAttribute("errorMsg", "Something Wrong On Server");
        	}
    	}
    	
    	
    }catch(Exception e) {
    	e.printStackTrace();
    }
    	
	   return "redirect:/signup";
   }
    
    //forget password method
    
    @GetMapping("/forget")
    public String forgetPassword() {
    	
    	return "forget_password";
    }
    
    @PostMapping("/forget")
    public String forgetPassword(@RequestParam String email, HttpSession session, HttpServletRequest request) {
    	UserDtls userByEmail = userService.getUserByEmail(email);
    	
    	if(ObjectUtils.isEmpty(userByEmail)) {
    		session.setAttribute("errorMsg", "Invalid email !");
    	}else {
    		
    		   String resetToken = UUID.randomUUID().toString();   //Reset email process
    		  userService.updateUserResetToken(email,resetToken);
    		  
    		  //Generated Url =>http://localhost:8082/reset?token=freutuee
    		 String url =CommonUtil.generateUrl(request)+"/reset?token="+resetToken;
    		   
    		  Boolean sendMail;
			try {
				sendMail = commonUtil.sendMail(url, email);
				
				if(sendMail) {
	    			  session.setAttribute("successMsg", "Please check your email..password reset link sent !");
	    		  }
	    		  else {
	    			  session.setAttribute("errorMsg", "Something wrong your email ! Enter your correct Email");
	    		  }
			} catch (Exception e) {
				
				e.printStackTrace();
			}
    		 
    	}
    	return "redirect:/forget";
    }
    
     //reset password method
    
    @GetMapping("/reset")
    public String resetPassword() {
    	
    	return "reset_password";
    }
    
    //Product Searching method
    @GetMapping("/searchProduct")
     public String searchProduct(@RequestParam String ch, Model m) {
    	 List<Product> searchProduct = productService.searchProduct(ch);
    	 m.addAttribute("products",searchProduct);
    	 
    	List<Category> categories = categoryService.getAllActiveCategory();
    	m.addAttribute("categories",categories);
    	 return "product";
     }
    
}

package com.ecomm.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecomm.model.Cart;
import com.ecomm.model.Category;
import com.ecomm.model.OrderRequest;
import com.ecomm.model.ProductOrder;
import com.ecomm.model.UserDtls;
import com.ecomm.service.CartService;
import com.ecomm.service.CategoryService;
import com.ecomm.service.OrderService;
import com.ecomm.service.UserService;
import com.ecomm.util.CommonUtil;
import com.ecomm.util.OrderStatus;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/user")
public class UserController {

  
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@GetMapping("/")
     public String home() {
	   System.out.println("Home Pages");
	   
	   return "user/home";
   }
	
	@ModelAttribute
	public void getUserDetails(Principal p, Model m) {
		
		if(p != null) {
			String email= p.getName();
			UserDtls userEmail = userService.getUserByEmail(email);
			m.addAttribute("user",userEmail);
			Integer countCart = cartService.getCountCart(userEmail.getId());
			m.addAttribute("countCart", countCart);
			
		}
		List<Category> category = categoryService.getAllActiveCategory();
		m.addAttribute("categorys",category);
	}
	

	@GetMapping("/cart")
	public String loadCart(Principal p, Model m) {
			
		UserDtls user = getLoggedUserDetails(p);
		
		List<Cart> carts= cartService.getCartsByUser(user.getId());
		m.addAttribute("carts" ,carts);
		if(carts.size() >0) {
		Double totalOrderPrice = carts.get(carts.size()-1).getTotalOrderPrice();
		m.addAttribute("totalOrderPrice",totalOrderPrice);  
		}	
		return "/user/cart";
	}
     //update Quantity dec & inc
	
	@GetMapping("/cartQuantityUpdate")
	public String updateCartQuantity(@RequestParam String sy, @RequestParam Integer cid) {
		
		cartService.updateQuantity(sy,cid);
		return "redirect:/user/cart";
	}
	
	
	private UserDtls getLoggedUserDetails(Principal p) {
	    
		String email = p.getName();
		UserDtls userDtls = userService.getUserByEmail(email);
		
		return  userDtls;
	}
	
	//Order method
	@GetMapping("/orders")
	public String orderPage(Principal p, Model m) {
		
        UserDtls user = getLoggedUserDetails(p);
		
		List<Cart> carts= cartService.getCartsByUser(user.getId());
		m.addAttribute("carts" ,carts);
		if(carts.size() >0) {
		Double orderPrice = carts.get(carts.size()-1).getTotalOrderPrice();
		Double totalOrderPrice = carts.get(carts.size()-1).getTotalOrderPrice()+ 50 + 100;
		m.addAttribute("orderPrice",orderPrice); 
		m.addAttribute("totalOrderPrice",totalOrderPrice); 
		}  	
		
		return "/user/orders";
	}
	
	@PostMapping("/save-order")
	public String saveOrder(@ModelAttribute OrderRequest request, Principal p) {
		
		System.out.println(request); 
		UserDtls user = getLoggedUserDetails(p);
		orderService.saveOrder(user.getId(), request);
			
		return "redirect:/user/success";
	}
	
	//Order success method
	@GetMapping("/success")
	public String loadSuccess() {
		
		return "/user/success";
		
	}
	//User Order Check method
	@GetMapping("/user-order")
	public String myOrder(Principal p, Model m) {
		UserDtls loginUser = getLoggedUserDetails(p);
		List<ProductOrder> orders = orderService.getOrdersByUser(loginUser.getId());
		m.addAttribute("orders", orders);
		
		return "/user/my_order";
		
	}
	
	//Order Cancel method
	@GetMapping("/cancel")   //update Status
	public String cancelUpdate(@RequestParam Integer id, @RequestParam Integer st, HttpSession session) {
		
		OrderStatus[] values = OrderStatus.values();
	   
		String status = null;
		for(OrderStatus orderSt : values) {
			if(orderSt.getId().equals(st)) {
				status = orderSt.getName();
			}
		}
		
		ProductOrder updateOrder = orderService.updateOrderStatus(id, status);
		
		try {
			commonUtil.sendMailProductOrder(updateOrder, status);
		}
		catch(Exception e) {
			e.printStackTrace();
		}  
		
		if(!ObjectUtils.isEmpty(updateOrder)) {
			session.setAttribute("successMsg", "Status Cancel Successfully");
		}else {
			session.setAttribute("errorMsg", "Something Wrong Cancel status");
		}
		return "redirect:/user/user-order";
	}	
	
	@GetMapping("/profile")
	public String profile() {
		
		return "/user/profile";
	}
	
	// profile update
	@PostMapping("/update-profile")
	public String updateProfile(@ModelAttribute UserDtls user, @RequestParam MultipartFile image, HttpSession session) {
		UserDtls updateUserProfile = userService.updateUserProfile(user, image);
		
		if(ObjectUtils.isEmpty(updateUserProfile)) {
			
			session.setAttribute("errorMsg", "profile is not Updated ");
		}else {
			session.setAttribute("successMsg", "profile is Updated ");
		}
		return "redirect:/user/profile";
	}
	
	//Change Password in  User Profile
	@PostMapping("/changePassword")
	public String ChangePassword(@RequestParam String newPassword, @RequestParam String currentPassword, Principal p, HttpSession session) {
		
		UserDtls loggedUserDetails = getLoggedUserDetails(p);
		boolean matches = passwordEncoder.matches(currentPassword, loggedUserDetails.getPassword());
		
		if(matches) {
			String encodePassword = passwordEncoder.encode(newPassword);
			loggedUserDetails.setPassword(encodePassword);
			UserDtls updateUser = userService.updateUser(loggedUserDetails);
			
			if(ObjectUtils.isEmpty(updateUser)) {
				
				session.setAttribute("errorMsg", " Password not update ! Try Again");
			}else {
				session.setAttribute("successMsg", "Password Updated successfully");
			}
			   
		}else {
			session.setAttribute("errorMsg", "Currnet Password Incorrect !");
		}
		return "redirect:/user/profile";
	}
	
}

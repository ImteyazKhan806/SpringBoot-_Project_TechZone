package com.ecomm.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecomm.model.Category;
import com.ecomm.model.Product;
import com.ecomm.model.ProductOrder;
import com.ecomm.model.UserDtls;
import com.ecomm.service.CartService;
import com.ecomm.service.CategoryService;
import com.ecomm.service.OrderService;
import com.ecomm.service.ProductService;
import com.ecomm.service.UserService;
import com.ecomm.util.CommonUtil;
import com.ecomm.util.OrderStatus;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private CommonUtil commonUtil;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@ModelAttribute
	public void getUserDetails(Principal p, Model m) {
		
		if(p != null) {
			String email= p.getName();
			UserDtls userEmail = userService.getUserByEmail(email);
			m.addAttribute("user",userEmail);
			Integer countCart = cartService.getCountCart(userEmail.getId());
			m.addAttribute("countCart", countCart);
			
		}
		List<Category> category = categoryService.getAllActiveCategory();
		m.addAttribute("categorys",category);
	}

	@GetMapping("/")
	public String index() {

		return "admin/index";
	}

	@GetMapping("/loadAddProduct")
	public String addProduct(Model m) {

		List<Category> categories = categoryService.getAllCategory();
		m.addAttribute("categories", categories);
		return "admin/add_product";
	}

	@PostMapping("/saveProduct")
	public String saveProduct(@ModelAttribute Product product, @RequestParam("file") MultipartFile file,
			HttpSession session) {
		try {

			String imageName = file.isEmpty() ? "default.jpg" : file.getOriginalFilename();
			
			product.setImage(imageName);
			product.setDiscount(0);
			product.setDiscountPrice(product.getPrice());
			
			Product saveProduct = productService.saveProduct(product);

			if (!ObjectUtils.isEmpty(saveProduct)) {

				File savefile = new ClassPathResource("static/images").getFile();

				Path path = Paths.get(savefile.getAbsolutePath() + File.separator + "product_img" + File.separator
						+ file.getOriginalFilename());
				// System.out.println(path); // call the path of image

				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

				session.setAttribute("successMsg", " Product Saved SuccessFully");
			}

			else {
				session.setAttribute("errorMsg", "Something Wrong Product!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		productService.saveProduct(product);
		return "redirect:/admin/loadAddProduct";
	}

	@GetMapping("/category")
	public String category(Model m, @RequestParam(name = "pageNo", defaultValue = "0")Integer pageNo, @RequestParam(name = "pageSize", defaultValue = "10")Integer pageSize) {
	  //	m.addAttribute("categorys", categoryService.getAllCategory());
		
		Page<Category> page = categoryService.getAllCategoryPagination(pageNo, pageSize);
		List<Category> categorys = page.getContent();
		m.addAttribute("categorys",categorys);
		m.addAttribute("pageNo",page.getNumber());
		m.addAttribute("pageSize", page.getSize());
		m.addAttribute("totalElements", page.getTotalElements());
		m.addAttribute("totalPages", page.getTotalPages());
		m.addAttribute("isFirst", page.isFirst());
		m.addAttribute("isLast", page.isLast());
		return "admin/category";
	}

	@PostMapping("/saveCategory")
	public String saveCategory(@ModelAttribute Category category, @RequestParam("file") MultipartFile file,
			HttpSession session) {

		String imageName = file != null ? file.getOriginalFilename() : "default.jpg";
		category.setImageName(imageName);

		Boolean name = categoryService.existCategory(category.getName());
		if (name) {

			session.setAttribute("errorMsg", "Category Name is already exists");
		} else {
			Category name1 = categoryService.savCategory(category);

			if (ObjectUtils.isEmpty(name1)) {
				session.setAttribute("errorMsg", "Not saved ! internal server error");
			} else {

				try {
					File savefile = new ClassPathResource("static/images").getFile();

					Path path = Paths.get(savefile.getAbsolutePath() + File.separator + "category_img" + File.separator
							+ file.getOriginalFilename());
					System.out.println(path);

					Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

					session.setAttribute("successMsg", "Saved successFully");

				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}
		categoryService.savCategory(category);
		return "redirect:/admin/category";
	}

	@GetMapping("/delete/{id}")
	public String deleteCategory(@PathVariable int id, HttpSession session) {
		try {

			Boolean delete = categoryService.deleteCategory(id);

			System.out.println("Delete result: " + delete);

			if (delete) {

				session.setAttribute("successMsg", "Category deleted successfully");
			} else {
				session.setAttribute("errorMsg", "Failed to delete category ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/category";
	}

	@GetMapping("/loadUpadte/{id}")
	public String loadUpdateCategory(@PathVariable int id, Model m) {
		m.addAttribute("category", categoryService.getCategoryById(id));
		return "admin/update_category";
	}

	@PostMapping("/updatecategory")
	public String updateCategory(@ModelAttribute Category category, @RequestParam("file") MultipartFile file,
			HttpSession session) {
		try {

			Category oldcategory = categoryService.getCategoryById(category.getId());
			String imageName = file.isEmpty() ? oldcategory.getImageName() : file.getOriginalFilename();

			if (!ObjectUtils.isEmpty(category)) {

				oldcategory.setName(category.getName());
				oldcategory.setIsActive(category.getIsActive());
				oldcategory.setImageName(imageName);
				
			}

			Category updateCategory = categoryService.savCategory(oldcategory);
			if (!ObjectUtils.isEmpty(updateCategory)) {

				if (!file.isEmpty()) {

					File savefile = new ClassPathResource("static/images").getFile();

					Path path = Paths.get(savefile.getAbsolutePath() + File.separator + "category_img" + File.separator
							+ file.getOriginalFilename());
					System.out.println(path);

					Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

					session.setAttribute("successMsg", "Saved successFully");
				}
				session.setAttribute("successMsg", "Update is SuccessFully!");
			} else {
				session.setAttribute("errorMsg", "Something Wrong Upadte!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/loadUpadte/" + category.getId();
	}

	@GetMapping("/products")
	public String viewProduct(Model m, @RequestParam(defaultValue = " ") String ch,
			@RequestParam(name = "pageNo", defaultValue = "0")Integer pageNo, 
			@RequestParam(name= "pageSize", defaultValue = "10")Integer pageSize) {
	/*	List<Product> products = null;
		
		if(ch != null && ch.length() > 0) {
			products = productService.searchProduct(ch);
		}
		else {
			products = productService.getAllProduct();
		}
		m.addAttribute("products", products); */
		
		Page<Product> page = null;
		if(ch != null && ch.length() > 0) {
		page =	productService.searchProductPagination(pageNo, pageSize, ch);	
		}else {
			page = productService.getAllProductPagination(pageNo, pageSize);
		}
		m.addAttribute("products",page.getContent());
		m.addAttribute("pageNo",page.getNumber());
		m.addAttribute("pageSize", page.getSize());
		m.addAttribute("totalElements", page.getTotalElements());
		m.addAttribute("totalPages", page.getTotalPages());
		m.addAttribute("isFirst", page.isFirst());
		m.addAttribute("isLast", page.isLast());
		return "admin/view_product";
	}

	@GetMapping("/deleteProduct/{id}")
	public String deleteProduct(@PathVariable int id, HttpSession session) {
		try {

			Boolean delete = productService.deleteProduct(id);
			System.out.println("Delete Success " + delete);

			if (delete) {
				session.setAttribute("successMsg", "Pruduct Deleted Successfully");
			} else {
				session.setAttribute("errorMsg", "Something Wrong Product");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/products";
	}

	@GetMapping("/editProduct/{id}")
	public String updateProduct1(@PathVariable int id, Model m) {
		try {

			m.addAttribute("product", productService.getProductById(id));
			m.addAttribute("categories", categoryService.getAllCategory());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "admin/update_product";
	}

	@PostMapping("/updateProduct")
	public String updateProduct(@ModelAttribute Product product, @RequestParam("file") MultipartFile image,
			HttpSession session) {
		try {
			Product dbProduct = productService.getProductById(product.getId());
			String imageName = image.isEmpty() ? dbProduct.getImage() : image.getOriginalFilename();

			if (product.getDiscount() < 0 || product.getDiscount() > 100) {
				session.setAttribute("errorMsg", "Invalid Discount! Discount must be between 0 and 100.");
				
			}

			if (!ObjectUtils.isEmpty(product)) {
				// Calculate discounted price
				Double originalPrice = product.getPrice();
				Double discount = originalPrice * (product.getDiscount() / 100.0);
				Double discountedPrice = originalPrice - discount;

				// Set updated values to dbProduct
				dbProduct.setTitle(product.getTitle());
				dbProduct.setDescription(product.getDescription());
				dbProduct.setCategory(product.getCategory());
				dbProduct.setStock(product.getStock());
				dbProduct.setImage(imageName);
				dbProduct.setIsActive(product.getIsActive());
				dbProduct.setDiscount(product.getDiscount());
				dbProduct.setDiscountPrice(discountedPrice);
			}

			Product updatedProduct = productService.saveProduct(dbProduct);

			if (!ObjectUtils.isEmpty(updatedProduct)) {
				// Save image if new one uploaded
				if (!image.isEmpty()) {
					File saveFileDir = new ClassPathResource("static/images").getFile();
					Path path = Paths.get(saveFileDir.getAbsolutePath(), "product_img", image.getOriginalFilename());
					Files.copy(image.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				}
				session.setAttribute("successMsg", "Product updated successfully.");
			} else {
				session.setAttribute("errorMsg", "Something went wrong during update.");
			}

		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("errorMsg", "Image upload failed.");
		}

		return "redirect:/admin/editProduct/" + product.getId();
	}
	
	@GetMapping("/users")
	public String  getAllUsers(Model m, @RequestParam Integer type) {
		List<UserDtls> users = null;
		
		if(type == 1) {
			users = userService.getUsers("ROLE_USER");
		}else {
			users = userService.getUsers("ROLE_ADMIN");
		}
		m.addAttribute("userType",type);
		m.addAttribute("users",users);
		return "/admin/users";
	}
	
	@GetMapping("/updateStatus")
	public String updateUserAccountStatus(@RequestParam Boolean status, @RequestParam Integer id,@RequestParam Integer type, HttpSession session) {
		
	Boolean f = userService.updateAccountStatus(id, status);
	
       if(f) {
    	     session.setAttribute("successMsg", "Account Status Updated");
       }else {
    	   session.setAttribute("errorMsg", "Something Wrong Account Update");
       }
		return "redirect:/admin/users?type="+type;
	}
	
	//admin order page
	
	@GetMapping("/orders")
	public String  getAllOrders(Model m, @RequestParam(defaultValue = "") String ch, 
			@RequestParam(name = "pageNo", defaultValue = "0")Integer pageNo, 
			@RequestParam(name= "pageSize", defaultValue = "10")Integer pageSize) {
//		List<ProductOrder> allOrders = orderService.getAllOrders();
//	    m.addAttribute("orders" ,allOrders);
//	    m.addAttribute("srch", false);
		
    Page<ProductOrder> page = orderService.getAllOrdersPagination(pageNo, pageSize);
	m.addAttribute("orders" ,page.getContent());
    m.addAttribute("srch", false);
    
	m.addAttribute("pageNo",page.getNumber());
	m.addAttribute("pageSize", page.getSize());
	m.addAttribute("totalElements", page.getTotalElements());
	m.addAttribute("totalPages", page.getTotalPages());
	m.addAttribute("isFirst", page.isFirst());
	m.addAttribute("isLast", page.isLast());
		return "/admin/orders";
	}
	
	//Update order status
		@PostMapping("/update-order-status")   //update Status
		public String cancelUpdate(@RequestParam Integer id, @RequestParam Integer st, HttpSession session) {
			
			OrderStatus[] values = OrderStatus.values();
		   
			String status = null;
			for(OrderStatus orderSt : values) {
				if(orderSt.getId().equals(st)) {
					status = orderSt.getName();
				}
			}
			
			ProductOrder updateOrder = orderService.updateOrderStatus(id, status);
			try {
				
				commonUtil.sendMailProductOrder(updateOrder, status);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		
			
			if(!ObjectUtils.isEmpty(updateOrder)) {
				session.setAttribute("successMsg", "Status Updated Successfully");
			}else {
				session.setAttribute("errorMsg", "Something Wrong Update status!");
			}
			return "redirect:/admin/orders";
		}
		
		@GetMapping("/searchOrder")
		public String searchOrder(@RequestParam String orderId, Model m, HttpSession session,
				@RequestParam(name = "pageNo", defaultValue = "0")Integer pageNo, 
				@RequestParam(name= "pageSize", defaultValue = "10")Integer pageSize	) {
			
			if(orderId != null && orderId.length() > 0) {
			ProductOrder orders = orderService.getOrdersByOrderId(orderId.trim());
			
			if(ObjectUtils.isEmpty(orders)) {
				session.setAttribute("errorMsg", "Incorrect orderId");
				m.addAttribute("orderDtls",null);
			}else {
				m.addAttribute("orderDtls",orders);
			}
			m.addAttribute("srch", true);
			}else {
				//with out pagenation method
				
//		        List<ProductOrder> allOrders = orderService.getAllOrders();
//		        m.addAttribute("orders",allOrders);
//		        m.addAttribute("srch", false);
				
			Page<ProductOrder> page = orderService.getAllOrdersPagination(pageNo, pageSize);
			m.addAttribute("orders",page);
			m.addAttribute("srch", false);
			
			m.addAttribute("pageNo",page.getNumber());
			m.addAttribute("pageSize", page.getSize());
			m.addAttribute("totalElements", page.getTotalElements());
			m.addAttribute("totalPages", page.getTotalPages());
			m.addAttribute("isFirst", page.isFirst());
			m.addAttribute("isLast", page.isLast());
			
			}
			return "/admin/orders";
		}
		
		//Add admin method 
		
		@GetMapping("/addAdmin")
		public String loadAdminAdd() {
			
			return "/admin/add_admin";
		}
		
		 @PostMapping("/saveAdmin")
		   public String saveAdmin(@ModelAttribute UserDtls user, @RequestParam("image") MultipartFile file, HttpSession session)  {
			   
		    try {
		    	
		     String imageName = file.isEmpty() ? "default.jpg" : file.getOriginalFilename();
		         user.setProfileImage(imageName);
		         
		    	UserDtls saveAdmin = userService.saveAdmin(user);
		    	if(!ObjectUtils.isEmpty(saveAdmin)) {
		    		
		    		if(!file.isEmpty()) {
		    			
							
		    				File savefile = new ClassPathResource("static/images").getFile();

		    				Path path = Paths.get(savefile.getAbsolutePath() + File.separator + "profile_img" + File.separator
		    						+ file.getOriginalFilename());
		    				// System.out.println(path); // call the path of image

		    				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
		    				
		    		}
		    		session.setAttribute("successMsg", " Signup Saved successfully");
		    	}else {
		    		session.setAttribute("errorMsg", "Something Wrong On Server");
		    	}
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
		    	
			   return "redirect:/admin/addAdmin";
		   }
		 
		 @GetMapping("/profile")
			public String profile() {
				
				return "/admin/profile";
			}
		 
			// profile update
		 @PostMapping("/update-profile")
			public String updateProfile(@ModelAttribute UserDtls user, @RequestParam ("file") MultipartFile image, HttpSession session) {
				UserDtls updateProfile = userService.updateUserProfile(user, image);
				if(ObjectUtils.isEmpty(updateProfile)) {
					session.setAttribute("errorMsg", "profile is not updated");
				}else {
					session.setAttribute("successMsg", "profile is updated");
				}
				return "redirect:/admin/profile";
			}
			
			//Change Password in  User Profile
			@PostMapping("/changePassword")
			public String ChangePassword(@RequestParam String newPassword, @RequestParam String currentPassword, Principal p, HttpSession session) {
				
				UserDtls loggedUserDetails = commonUtil.getLoggedUserDetails(p);
				boolean matches = passwordEncoder.matches(currentPassword, loggedUserDetails.getPassword());
				
				if(matches) {
					String encodePassword = passwordEncoder.encode(newPassword);
					loggedUserDetails.setPassword(encodePassword);
					UserDtls updateUser = userService.updateUser(loggedUserDetails);
					
					if(ObjectUtils.isEmpty(updateUser)) {
						
						session.setAttribute("errorMsg", " Password not update ! Try Again");
					}else {
						session.setAttribute("successMsg", "Password Updated successfully");
					}
					   
				}else {
					session.setAttribute("errorMsg", "Currnet Password Incorrect !");
				}
				return "redirect:/admin/profile";
			}
}

package com.ecomm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecomm.model.Cart;
import com.ecomm.service.CartService;


import jakarta.servlet.http.HttpSession;

@Controller
public class CartController {

	
	
	@Autowired
	private CartService cartService;
	
	//addCart 
		@GetMapping("/addCart")
		public String addToCart(@RequestParam Integer pid, @RequestParam Integer uid, HttpSession session) {
		   // System.out.println("This is AddCart");   
			
			Cart saveCart = cartService.saveCart(pid, uid);
		    
		    if (ObjectUtils.isEmpty(saveCart)) {
		        session.setAttribute("errorMsg", "Product add to cart failed !");
		    } else {
		        session.setAttribute("successMsg", "Product added to cart successfull !");
		    }
		    return "redirect:/product/" +pid;
		}
		
}

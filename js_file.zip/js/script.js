$(function(){
	
	var $userRegister=$("#userRegister");
	
	$userRegister.validate({
		
		rules:{
			name:{
				required:true,
				letteronly:true
			},
			email:{
				required:true,
				space:true,
				email:true
				
			},
			mobileNumber:{
				required:true,
				space:true,
				numberonly:true,
				minlength:10,
				maxlength:12
			},
			password:{
				required:true,
				space:true,
			},
			cpassword:{
					required:true,
					space:true,
					equalTo:'#pass'
			},
			address:{
					required:true,
				    all:true,
			},
			city:{
					 required:true,
			   		 space:true,
			},
			state:{
					required:true,
				   
			},
			pincode:{
				   required:true,
				   space:true,
				   numbericOnly:true
			},
		    image:{
					required:true,
							   
			},
			
	     },
		messsge:{
			name:{
				required:'name required',
				letteronly:'Invalid name'
			}
		}
	})
})

// Allows only letters, spaces, and hyphens, but does not start with hyphen or space
jQuery.validator.addMethod('letteronly', function(value, element) {
    return this.optional(element) || /^[^-\s][a-zA-Z\s-]+$/.test(value);
};

// Does not allow leading hyphens or spaces
jQuery.validator.addMethod('space', function(value, element) {
    return this.optional(element) || /^[^-\s]+$/.test(value);
};

// Allows alphanumeric characters, underscore, comma, period, spaces, and hyphens; no leading hyphen or space
jQuery.validator.addMethod('alphanumericSpecial', function(value, element) {
    return this.optional(element) || /^[^-\s][a-zA-Z0-9_,.\s-]+$/.test(value);
};

// Allows only numbers
jQuery.validator.addMethod('numberonly', function(value, element) {
    return this.optional(element) || /^[0-9]+$/.test(value);
};

package com.ecomm.repositary;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecomm.model.Category;

public interface CategoryRepositary  extends JpaRepository<Category, Integer>{

	  Boolean existsByName (String name);

	public  List<Category> findByIsActiveTrue();
	 
	 
	  
}

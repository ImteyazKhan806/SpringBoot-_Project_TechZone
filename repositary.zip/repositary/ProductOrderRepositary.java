package com.ecomm.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecomm.model.ProductOrder;

public interface ProductOrderRepositary extends JpaRepository<ProductOrder, Integer>{

	List<ProductOrder> findByUserId(Integer userId);

	ProductOrder findByOrderId(String orderId);

	

	

}

package com.ecomm.config;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;


import com.ecomm.model.UserDtls;
import com.ecomm.repositary.UserRepository;
import com.ecomm.service.UserService;
import com.ecomm.util.AppConstant;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class AuthFailureHandlerImpl extends SimpleUrlAuthenticationFailureHandler{

	 @Autowired
	 private UserRepository userRepository;
	 
	 @Autowired
	 private UserService userService;
	
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		
		  String email= request.getParameter("username");
		  
		  UserDtls userEmail = userRepository.findByEmail(email);
		  
		  if(userEmail != null) {
		  if(userEmail.getIsEnable()) {
			 
			  if(userEmail.getAccountNonLocked()){
				  
				  if(userEmail.getFailedAttempt() < AppConstant.ATTEMPT_TIME) {
					  
					  userService.increaseFailedAttempt(userEmail);
				  }
				  else {
					     userService.userAccountLock(userEmail);
					     exception = new LockedException("Your account is Locked !! failed attempt 3");
				  }
				 
			  }else {
				  
				   if(userService.unlockAccountTimeExpired(userEmail)) {
					   
					   exception = new LockedException("Your account is UnLocked !! Please try to Login");
					   
				   }else {
					   
				     exception = new LockedException("Your account is Locked !! Please try after sometimes ! ");
			      }
			  }	   
			  
		  }else {
			  exception = new LockedException("Your account is Inactive !");
		  }
		  }else {
			  exception = new LockedException("Your email & password Invalid ");
		  }
		super.setDefaultFailureUrl("/signin?error");
		super.onAuthenticationFailure(request, response, exception);
	}
	
	

}
